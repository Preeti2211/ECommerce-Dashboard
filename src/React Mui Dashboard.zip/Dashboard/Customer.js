function Customer()
{
    return (
        <div>
            <h1>add product page</h1>
        </div>
    )
}
export default Customer;