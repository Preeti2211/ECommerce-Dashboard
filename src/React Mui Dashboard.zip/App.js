import React from 'react';
import { BrowserRouter , Route, Routes } from 'react-router-dom';
import Dashboard from './Dashboard';
import UpdateProduct from './Dashboard/UpdateProduct';
import AddProduct from './Dashboard/AddProduct';
import Order from './Dashboard/Order';

const App = () => {

  return (
    <BrowserRouter>
    <Routes>
        <Route path='/' element={<Dashboard />}></Route>
        <Route path='/product' element={<UpdateProduct />}></Route>
        <Route path='/addproduct' element={<AddProduct />}></Route>
        <Route path='/order' element={<Order/>} />
    </Routes>
  </BrowserRouter>
  );
};

export default App;
